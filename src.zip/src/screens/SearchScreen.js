import React, {useState} from 'react'
import {View, Text, StyleSheet} from 'react-native'
import { TextInput } from 'react-native-gesture-handler'
import SearchBar from "../components/SearchBar"
import { Feather } from '@expo/vector-icons';  

const SearchScreen = () => {
    const [term, setTerm] = useState('')
    
    return <View>
        <SearchBar 
        term = {term} 
        onChangeTerm = {(newTerm) => {setTerm(newTerm)
       
        
        }
        }
        onTermSubmit = {() => {console.log('Submitted')}}
        
        
        />
<Text> Search Screen</Text>
<Text>{term}</Text>

    </View>
}

const styles = StyleSheet.create({

    textStyle: {
        fontSize: 30
    }
})

export default SearchScreen;