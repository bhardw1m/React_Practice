import React, { useState } from 'react'
import {View, Text, StyleSheet} from 'react-native'
import { TextInput, TouchableOpacity } from 'react-native-gesture-handler'
import { Feather } from '@expo/vector-icons';  

const SearchBar = ({term, onChangeTerm, onTermSubmit}) => {
    let content = '';
    //const [state,setState] = useState('true');
    let stateval = 'true';
    const mVal = (myVal) => {
        console.log(myVal)
        if(myVal === '')
        stateval = 'true';
      else
        stateval = 'false';

    }
    
    return <View style = {styles.backgroundStyle}>
       
     
     {
     
     stateval === 'true' ? ( <Feather name="search" size={24} color="black" />) : null}       
        
        <TextInput style = {styles.textStyle} placeholder="search" 
        autoCorrect = {true}
         
        value = {term}
        onChangeText = {(newTerm) => {
            
            mVal(newTerm)
            content = newTerm;
            console.log(content);
            onChangeTerm(newTerm);    
        }
        
        }
        onEndEditing = { () => {
            mVal(content);
            onTermSubmit()
        }}
            
        
        
        
        /> 
        
    </View>
}

const styles = StyleSheet.create({

    backgroundStyle: {
        backgroundColor: "#EFE8E7",
        height: 50,
        margin: 15,
        borderRadius: 20,
        paddingLeft : 10,
        flexDirection : "row",
        alignItems : "center"
    },
    textStyle : {
        marginLeft : 10,
        fontSize : 20,
        flex : 1
    }
})

export default SearchBar;